#include<unistd.h>
#include<stdlib.h>
#include<sys/ipc.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<stdio.h>
#include<string.h>
#include<sys/wait.h>
struct m
{
char c[100];
char name[10];
int x;}*ptr;
int main()
{

int flag=1;
int key,shmid;
printf("Enter the key of shared memory segment you want to communicate with");
scanf("%d",&key);
shmid=shmget(key,1000,IPC_CREAT|0666);
ptr=(struct m*)shmat(shmid,0,0);
printf("Enter your name:");
scanf("%s",ptr->name);
//printf("%s \n",ptr->name);
//char *s;
printf("You :");
scanf("%s",ptr->c);
//gets(s);
//strcpy(ptr->c,s);
sleep(15);
printf("%s : %s\n",ptr->name,ptr->c);

while(flag==1)
{
if(ptr->x==1) continue;

printf("You :");
scanf("%s\n",ptr->c);
ptr->x=1;
sleep(8);
printf("%s : %s\n",ptr->name,ptr->c);
}



}

