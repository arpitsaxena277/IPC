#include<stdio.h>
#include<semaphore.h>
#include<unistd.h>
#include<stdlib.h>
#include<pthread.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
int main()
{ 
time_t t;
struct tm *ti;

int i;
int c;

int key;
printf("Enter the key of the semaphore through which you wish to communicate");
scanf("%d",&key);
int semid=semget(key,1,IPC_CREAT|0666);
printf("Enter the number of pages you want to send to receiver");
scanf("%d",&c);

int v[c];
int v1[c];
printf("Enter the pages");
for(i=0;i<c;i++)
{
scanf("%d",&v[i]);


}// semaphores can be 25 max in a pc
semctl(semid,0,SETVAL,c);


for(i=0;i<c;i++)
{
semid=semget(++key,0,IPC_CREAT|0666);
semctl(semid,0,SETVAL,v[i]);
}
time(&t);
ti=localtime(&t);
printf("Pages sent successfully to the receiver at time %s",asctime(ti));
/*key=1;
printf("Pages Received :");
for(i=0;i<c;i++)
{
semid=semget(++key,0,IPC_CREAT|0666);
v1[i]=semctl(semid,0,GETVAL,0);
printf("%d ",v1[i]);
}*/



}
