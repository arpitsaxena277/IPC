#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
struct 
{
long type;
char text[15];
}message;

int main()
{
int x=0;
char s[100];
int c=1;
key_t k=1;
int qid,len;
int msgid;
msgid=msgget(k,IPC_CREAT|0644);//0644 permission for everyone and 0666 read write for everybody
if(msgid<0)
printf("Creation of the message queue failed\n");
else 
printf("Message queue created with key %d\n",msgid);
k=2;
msgid=msgget(k,IPC_CREAT|0666);//0644 permission for everyone and 0666 read write for everybody
if(msgid<0)
printf("Creation of the message queue failed\n");
else 
printf("Message queue created with key %d\n",msgid);
k=3;
msgid=msgget(k,IPC_CREAT|0);//0644 permission for everyone and 0666 read write for everybody
if(msgid<0)
printf("Creation of the message queue failed\n");
else 
printf("Message queue created with key %d\n",msgid);
// For this intance , I am working on message queue 2.
struct msqid_ds q;

printf("Enter the key of the queue you want to work on \n");
scanf("%d",&k);
int p;
while(c!=0)
{
printf("Enter a message for message queue\n");
scanf("%s",s);
strncpy(message.text,s,strlen(s)); 
printf("Enter the priority number for this msg\n");
scanf("%d",&p);
message.type=p;
len=strlen(message.text);
qid=msgget(k,IPC_CREAT|0666);
if(msgsnd(qid,&message,len,IPC_NOWAIT)==-1)
{perror("Message send failed");exit(0);}
if(msgctl(qid,IPC_STAT,&q)<0)
{perror("Message status retrieval failed");exit(0);}
printf("Message queue id: %d\n",qid);
printf("Number of message in queue : %lu\n",q.msg_qnum);
printf("Last Msg sent by you was at : %s\n",ctime(&(q.msg_stime)));
printf("Last Msg received by receiver was at : %s\n",ctime(&(q.msg_rtime)));
printf("Enter 0 to stop sending msgs");
scanf("%d",&c);

}
return 0;
}








