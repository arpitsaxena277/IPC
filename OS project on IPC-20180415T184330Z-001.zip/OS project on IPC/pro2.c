#include<unistd.h>
#include<stdlib.h>
#include<sys/ipc.h>
#include<sys/types.h>
#include<sys/shm.h>
#include<stdio.h>
#include<string.h>
#include<sys/wait.h>
struct m
{
char c[100];
char name[10];
int x;}*ptr;
int main()
{
int m=0;
int flag=1;
int key,shmid;
printf("Enter the key of shared memory segment you want to communicate with");
scanf("%d",&key);
shmid=shmget(key,1000,IPC_CREAT|0666);
ptr=(struct m*)shmat(shmid,0,0);
 char buddy[20];
strcpy(buddy,ptr->name);
printf("Enter your name");
scanf("%s",ptr->name);

printf(" %s : %s\n",buddy,ptr->c);


printf("You:");
scanf("%s",ptr->c);
ptr->x=0;
while(flag==1)
{  
if(ptr->x==0) 
continue;
if(m==1) break;
printf("You :");
scanf("%s\n",ptr->c);
m++;
ptr->x=0;
sleep(8);
printf("%s : %s\n",ptr->name,ptr->c);
}
printf("%s : %s",ptr->name,ptr->c);

}
