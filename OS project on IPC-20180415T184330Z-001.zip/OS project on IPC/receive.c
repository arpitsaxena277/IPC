#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/msg.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
struct 
{
long type;
char text[15];
}buff;
int main()
{
int c=1;
int key;
printf("Enter the key of the queue from which you want to communicate with:\n");
scanf("%d",&key);
int p;
int qid;
qid=msgget(key,IPC_CREAT|0666);

while(c!=0)
{ 
printf("Enter priority number to receive the message");
scanf("%d",&p);
if(msgrcv(qid,&buff,15,p,IPC_NOWAIT|MSG_NOERROR)==-1)
{
perror("Message receive failed");
exit(1);
}
printf("Message in the queue was %s\n",buff.text);


printf("Enter 1 to receive more msgs");
scanf("%d",&c);

}
return 0;
}
